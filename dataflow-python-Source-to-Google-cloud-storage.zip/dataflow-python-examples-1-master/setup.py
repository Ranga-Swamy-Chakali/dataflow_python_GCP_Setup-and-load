from setuptools import setup

setup(name='dataflow_python_examples',
      version='1.0',
      description='Python Dataflow Examples',
      author='Josh McGinley',
      url='https://github.com/GoogleCloudPlatform/professional-services/tree/master/data-analytics',
      packages=['dataflow_python_examples'],
     )